﻿using System;


ProxyMessenger Messenger = new ProxyMessenger();
Messenger.SendMessage("Hey, How're you?");


interface IMessenger
{
    void SendMessage(string text);
}


class Telegram : IMessenger
{
    public void SendMessage(string text)
    {
        Console.WriteLine(text);
    }
}

class Whatsapp : IMessenger
{
    public void SendMessage(string text)
    {
        Console.WriteLine(text);
    }
}


class ProxyMessenger : IMessenger
{
    private IMessenger _whatsapp;
    private IMessenger _telegram;

    public ProxyMessenger()
    {
        _whatsapp = new Whatsapp();
        _telegram = new Telegram();
    }

    public void SendMessage(string text)
    {
        try
        {
            _whatsapp.SendMessage($"Notification from Whatsapp: {text}");
        }
        catch (Exception e)
        {
            _telegram.SendMessage($"Notification from Telegram: {text}");
        }
    }
}